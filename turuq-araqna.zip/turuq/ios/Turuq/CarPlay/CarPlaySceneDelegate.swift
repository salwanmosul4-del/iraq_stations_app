import CarPlay
import MapKit
import UIKit

/// CarPlay: بحث → معاينة المسار → توجيه خطوة بخطوة. يتطلب صلاحية com.apple.developer.carplay-maps من Apple.
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate, CPMapTemplateDelegate, CPSearchTemplateDelegate {
    private var ic: CPInterfaceController?; private var window: CPWindow?; private var mapT: CPMapTemplate?
    private var session: CPNavigationSession?; private let model = AppModel.shared

    func templateApplicationScene(_ s: CPTemplateApplicationScene, didConnect ic: CPInterfaceController, to window: CPWindow) {
        self.ic = ic; self.window = window
        window.rootViewController = MapViewController()
        Task { @MainActor in model.start() }
        let t = CPMapTemplate(); t.mapDelegate = self; mapT = t
        let search = CPBarButton(title: "بحث") { [weak self] _ in self?.openSearch() }
        let report = CPBarButton(title: "أبلغ") { [weak self] _ in self?.openReport() }
        t.leadingNavigationBarButtons = [search]; t.trailingNavigationBarButtons = [report]
        ic.setRootTemplate(t, animated: true, completion: nil)
    }
    func templateApplicationScene(_ s: CPTemplateApplicationScene, didDisconnect ic: CPInterfaceController, from window: CPWindow) {
        self.ic = nil; self.window = nil
    }

    private func openSearch() { let s = CPSearchTemplate(); s.delegate = self; ic?.pushTemplate(s, animated: true, completion: nil) }

    func searchTemplate(_ t: CPSearchTemplate, updatedSearchText text: String, completionHandler: @escaping ([CPListItem]) -> Void) {
        guard text.count >= 2 else { return completionHandler([]) }
        Task { @MainActor in
            let places = (try? await model.api.search(text, near: model.hereP)) ?? []
            completionHandler(places.prefix(6).map { p in
                let i = CPListItem(text: p.name, detailText: p.area); i.userInfo = p; return i })
        }
    }
    func searchTemplate(_ t: CPSearchTemplate, selectedResult item: CPListItem, completionHandler: @escaping () -> Void) {
        completionHandler()
        guard let p = item.userInfo as? Place else { return }
        Task { @MainActor in
            await model.plan(to: p); ic?.popToRootTemplate(animated: false, completion: nil)
            let trip = CPTrip(origin: MKMapItem.forCurrentLocation(),
                              destination: MKMapItem(placemark: MKPlacemark(coordinate: .init(latitude: p.lat, longitude: p.lon))),
                              routeChoices: model.routes.prefix(3).map { r in
                                  CPRouteChoice(summaryVariants: [Fmt.minutes(r.durationS) + " · " + Fmt.dist(r.distanceM)], additionalInformationVariants: [r.label], selectionSummaryVariants: [r.label]) })
            mapT?.showTripPreviews([trip], textConfiguration: nil)
        }
    }

    func mapTemplate(_ t: CPMapTemplate, startedTrip trip: CPTrip, using choice: CPRouteChoice) {
        t.hideTripPreviews()
        Task { @MainActor in
            await model.startNavigation()
            session = t.startNavigationSession(for: trip)
            refresh()
            Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] tm in
                guard let self, self.model.navigating else { tm.invalidate(); self?.session?.finishTrip(); return }
                self.refresh()
            }
        }
    }
    func mapTemplateDidCancelNavigation(_ t: CPMapTemplate) { Task { @MainActor in model.stopNavigation() }; session?.cancelTrip() }

    @MainActor private func refresh() {
        guard let st = model.navState, let session else { return }
        let m = CPManeuver(); m.instructionVariants = [st.step.instruction]
        if let s = st.step.street { m.instructionVariants.append(s) }
        m.initialTravelEstimates = CPTravelEstimates(distanceRemaining: .init(value: st.distToManeuver, unit: .meters), timeRemaining: 0)
        session.upcomingManeuvers = [m] + (st.nextStep.map { n -> [CPManeuver] in let x = CPManeuver(); x.instructionVariants = [n.instruction]; return [x] } ?? [])
        session.updateEstimates(CPTravelEstimates(distanceRemaining: .init(value: st.distToManeuver, unit: .meters), timeRemaining: 0), for: m)
        if let w = st.nextWarning, let t = ReportType(rawValue: w.type) {
            mapT?.showBanner(CPNavigationAlert(titleVariants: ["\(t.label) بعد \(Fmt.dist(st.warningDist))"], subtitleVariants: nil, image: nil,
                                               primaryAction: CPAlertAction(title: "حسناً", style: .default) { _ in }, secondaryAction: nil, duration: 6))
        }
    }

    /// ٦ أنواع فقط لتقليل تشتيت السائق.
    private func openReport() {
        let items = ReportType.allCases.filter { $0.onCarGrid }.map { t -> CPListItem in
            let i = CPListItem(text: t.label, detailText: nil)
            i.handler = { [weak self] _, done in Task { @MainActor in await self?.model.report(t) }; self?.ic?.popTemplate(animated: true, completion: nil); done() }
            return i }
        ic?.pushTemplate(CPListTemplate(title: "ماذا ترى؟", sections: [CPListSection(items: items)]), animated: true, completion: nil)
    }
}
