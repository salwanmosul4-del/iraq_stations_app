import UIKit
import SwiftUI

@main final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ a: UIApplication, configurationForConnecting s: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        UISceneConfiguration(name: s.role == .carTemplateApplication ? "CarPlay" : "Phone", sessionRole: s.role)
    }
}

final class PhoneSceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    func scene(_ scene: UIScene, willConnectTo s: UISceneSession, options: UIScene.ConnectionOptions) {
        guard let ws = scene as? UIWindowScene else { return }
        window = UIWindow(windowScene: ws); window?.rootViewController = UIHostingController(rootView: ContentView()); window?.makeKeyAndVisible()
    }
}
