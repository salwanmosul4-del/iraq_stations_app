import SwiftUI

struct MapHost: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> MapViewController { MapViewController() }
    func updateUIViewController(_ vc: MapViewController, context: Context) {}
}

struct ContentView: View {
    @ObservedObject var m = AppModel.shared
    @State private var query = ""; @State private var results: [Place] = []
    @State private var fromQuery = ""; @State private var fromResults: [Place] = []; @State private var showFrom = false
    @State private var showReport = false; @AppStorage("welcomed") private var welcomed = false
    private let teal = Color(red: 0.055, green: 0.486, blue: 0.525), ink = Color(red: 0.06, green: 0.16, blue: 0.18)

    var body: some View {
        ZStack {
            MapHost().ignoresSafeArea()
            VStack(spacing: 8) {
                if m.navigating, let st = m.navState {
                    VStack(alignment: .trailing, spacing: 4) {
                        Text(Fmt.dist(st.distToManeuver)).font(.system(size: 30, weight: .heavy))
                        Text(st.step.instruction).font(.system(size: 16))
                        if let w = st.nextWarning, let t = ReportType(rawValue: w.type) {
                            Text("⚠ \(t.label) بعد \(Fmt.dist(st.warningDist))").foregroundColor(.yellow).bold()
                        }
                    }.frame(maxWidth: .infinity, alignment: .trailing).padding(16).background(ink).foregroundColor(.white).cornerRadius(20)
                } else {
                    TextField("إلى أين تريد الذهاب؟", text: $query).textFieldStyle(.roundedBorder).submitLabel(.search)
                        .onSubmit { Task { results = (try? await m.api.search(query, near: m.hereP)) ?? [] } }
                    HStack {
                        Button("من: " + (m.origin?.name ?? "موقعي")) { showFrom.toggle() }.buttonStyle(.bordered)
                        if m.origin != nil { Button("موقعي") { Task { await m.setOrigin(nil) } } }
                        Spacer()
                    }
                    if showFrom {
                        TextField("ابدأ من: منطقة، مبنى، دائرة…", text: $fromQuery).textFieldStyle(.roundedBorder).submitLabel(.search)
                            .onSubmit { Task { fromResults = (try? await m.api.search(fromQuery, near: m.hereP)) ?? [] } }
                        ForEach(fromResults.prefix(5)) { p in
                            Button(p.name + (p.area.isEmpty ? "" : " · " + p.area)) { fromResults = []; showFrom = false; Task { await m.setOrigin(p) } }
                                .frame(maxWidth: .infinity, alignment: .trailing).padding(10).background(.white).cornerRadius(10)
                        }
                    }
                    ForEach(results.prefix(6)) { p in
                        Button { results = []; query = p.name; Task { await m.plan(to: p) } } label: {
                            VStack(alignment: .trailing) { Text(p.name).bold(); if !p.area.isEmpty { Text(p.area).font(.caption).foregroundColor(.gray) } }
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }.padding(10).background(.white).cornerRadius(10)
                    }
                }
                Spacer()
                if let msg = m.message { Text(msg).padding(10).background(ink).foregroundColor(.white).cornerRadius(12).onTapGesture { m.message = nil } }
                bottomBar
            }.padding(12)
            if !welcomed { welcome }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .sheet(isPresented: $showReport) { reportSheet }
        .onAppear { m.start() }
    }

    @ViewBuilder var bottomBar: some View {
        if m.navigating, let st = m.navState {
            HStack {
                VStack(alignment: .trailing) { Text(Fmt.minutes(st.remainingS)).font(.title2.bold()).foregroundColor(teal); Text(Fmt.dist(st.remaining)).foregroundColor(.gray) }
                Spacer()
                Button("أبلغ") { showReport = true }.buttonStyle(.borderedProminent).tint(teal)
                Button("إنهاء") { m.stopNavigation() }.buttonStyle(.borderedProminent).tint(.red)
            }.padding(16).background(.white).cornerRadius(20)
        } else if !m.routes.isEmpty {
            VStack(alignment: .trailing, spacing: 6) {
                ForEach(Array(m.routes.prefix(3).enumerated()), id: \.offset) { i, r in
                    Button { m.selected = i } label: {
                        VStack(alignment: .trailing) {
                            Text(Fmt.minutes(r.durationS) + " · " + Fmt.dist(r.distanceM)).bold()
                            Text(r.label + (r.warnings.isEmpty ? "" : " · \(Fmt.num(Double(r.warnings.count))) تنبيه على الطريق")).font(.caption).foregroundColor(.gray)
                        }.frame(maxWidth: .infinity, alignment: .trailing).padding(10)
                            .background(i == m.selected ? Color(red: 0.89, green: 0.95, blue: 0.95) : .clear).cornerRadius(12)
                    }.foregroundColor(ink)
                }
                Button { Task { await m.startNavigation() } } label: { Text("ابدأ").font(.title3.bold()).frame(maxWidth: .infinity) }
                    .buttonStyle(.borderedProminent).tint(teal)
            }.padding(14).background(.white).cornerRadius(22)
        } else {
            HStack { Spacer(); Button { showReport = true } label: { Text("⚠").font(.title).frame(width: 56, height: 56) }
                .background(teal).foregroundColor(.white).clipShape(Circle()) }
        }
    }

    var reportSheet: some View {
        VStack(alignment: .trailing, spacing: 12) {
            Text("ماذا ترى على الطريق؟").font(.title3.bold())
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 8) {
                ForEach(ReportType.allCases, id: \.self) { t in
                    Button { Task { await m.report(t) }; showReport = false } label: {
                        Text(t.label).font(.footnote.bold()).frame(maxWidth: .infinity, minHeight: 72)
                            .background(t.isCamera ? Color(red: 0.93, green: 0.91, blue: 0.98) : Color(red: 0.95, green: 0.96, blue: 0.96)).cornerRadius(14)
                    }.foregroundColor(ink)
                }
            }
        }.padding(18).presentationDetents([.medium])
    }

    var welcome: some View {
        ZStack {
            ink.opacity(0.92).ignoresSafeArea()
            VStack(spacing: 18) {
                Text("🤖").font(.system(size: 90))   // يُستبدل بأصل الروبوت المتحرك من التصميم
                Text("أهلاً بك في أفضل تطبيق عراقي للطرق").font(.title2.bold()).foregroundColor(.white).multilineTextAlignment(.center)
                Text("اضغط للمتابعة").foregroundColor(.white.opacity(0.6))
            }.padding(32)
        }.onTapGesture { welcomed = true }
    }
}
