import MapLibre
import UIKit

/// نظير MapController في أندرويد: ستايل OpenMapTiles + طبقات المسار والبلاغات وسهم العلم.
final class MapController {
    let map: MLNMapView; private var style: MLNStyle?
    init(_ map: MLNMapView) { self.map = map }

    func load(files: [URL], dark: Bool, done: @escaping () -> Void) {
        guard let url = Bundle.main.url(forResource: "base", withExtension: "json"),
              var json = (try? JSONSerialization.jsonObject(with: Data(contentsOf: url))) as? [String: Any],
              let layers = json["layers"] as? [[String: Any]] else { return }
        var sources: [String: Any] = [:]; var ids: [String] = []
        if files.isEmpty { sources["omt"] = ["type": "vector", "tiles": ["https://tiles.turuq.example/data/iraq/{z}/{x}/{y}.pbf"], "maxzoom": 14]; ids = ["omt"] }
        else { for (i, f) in files.enumerated() { sources["omt\(i)"] = ["type": "vector", "url": "mbtiles://" + f.path]; ids.append("omt\(i)") } }
        var out: [[String: Any]] = []
        for l in layers { guard l["source"] != nil else { out.append(l); continue }
            for (k, s) in ids.enumerated() { var c = l; c["source"] = s; if k > 0 { c["id"] = "\(l["id"] as! String)#\(k)" }; out.append(c) } }
        json["sources"] = sources; json["layers"] = out
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("style.json")
        try? JSONSerialization.data(withJSONObject: json).write(to: tmp)
        map.styleURL = tmp
        pending = done
    }
    private var pending: (() -> Void)?

    func styleLoaded(_ s: MLNStyle) {
        style = s
        s.setImage(Self.flagArrow(), forName: "flag-arrow")
        for id in ["main-route", "alt-routes", "reports", "vehicle", "dest"] { s.addSource(MLNShapeSource(identifier: id, shape: nil, options: nil)) }
        func line(_ id: String, _ src: String, _ color: UIColor, _ w: CGFloat) {
            guard let so = s.source(withIdentifier: src) else { return }
            let l = MLNLineStyleLayer(identifier: id, source: so); l.lineColor = NSExpression(forConstantValue: color); l.lineWidth = NSExpression(forConstantValue: w)
            l.lineCap = NSExpression(forConstantValue: "round"); l.lineJoin = NSExpression(forConstantValue: "round"); s.addLayer(l)
        }
        line("alt-casing", "alt-routes", .white, 9); line("alt-line", "alt-routes", UIColor(red: 0.54, green: 0.63, blue: 0.64, alpha: 1), 5)
        line("main-casing", "main-route", .white, 13); line("main-line", "main-route", UIColor(red: 0.055, green: 0.486, blue: 0.525, alpha: 1), 8)
        if let so = s.source(withIdentifier: "reports") {
            let c = MLNCircleStyleLayer(identifier: "reports-dot", source: so); c.circleRadius = NSExpression(forConstantValue: 9)
            c.circleStrokeColor = NSExpression(forConstantValue: UIColor.white); c.circleStrokeWidth = NSExpression(forConstantValue: 2.5)
            c.circleColor = NSExpression(format: "TERNARY(t IN %@, %@, %@)", ["speedcam", "cam"], UIColor(red: 0.36, green: 0.25, blue: 0.82, alpha: 1), UIColor(red: 0.91, green: 0.57, blue: 0.18, alpha: 1))
            s.addLayer(c)
        }
        if let so = s.source(withIdentifier: "vehicle") {
            let v = MLNSymbolStyleLayer(identifier: "vehicle-arrow", source: so); v.iconImageName = NSExpression(forConstantValue: "flag-arrow")
            v.iconAllowsOverlap = NSExpression(forConstantValue: true); v.iconRotation = NSExpression(forKeyPath: "b")
            v.iconRotationAlignment = NSExpression(forConstantValue: "map"); s.addLayer(v)
        }
        pending?(); pending = nil
    }

    func showRoutes(_ routes: [Route], selected: Int) {
        func feat(_ r: Route) -> MLNPolylineFeature { var c = r.shape.map { $0.coord }; return MLNPolylineFeature(coordinates: &c, count: UInt(c.count)) }
        (style?.source(withIdentifier: "main-route") as? MLNShapeSource)?.shape = routes.indices.contains(selected) ? feat(routes[selected]) : nil
        (style?.source(withIdentifier: "alt-routes") as? MLNShapeSource)?.shape = MLNShapeCollectionFeature(shapes: routes.enumerated().filter { $0.offset != selected }.map { feat($0.element) })
    }
    func showReports(_ list: [Report]) {
        let fs: [MLNPointFeature] = list.map { r in let f = MLNPointFeature(); f.coordinate = .init(latitude: r.lat, longitude: r.lon); f.attributes = ["t": r.type, "id": r.id]; return f }
        (style?.source(withIdentifier: "reports") as? MLNShapeSource)?.shape = MLNShapeCollectionFeature(shapes: fs)
    }
    func setVehicle(_ p: GeoPoint, bearing: Double) {
        let f = MLNPointFeature(); f.coordinate = p.coord; f.attributes = ["b": bearing]
        (style?.source(withIdentifier: "vehicle") as? MLNShapeSource)?.shape = f
    }
    func follow(_ p: GeoPoint, bearing: Double) {
        map.setCamera(MLNMapCamera(lookingAtCenter: p.coord, altitude: 700, pitch: 50, heading: bearing), animated: true)
    }

    /// المثلث مع العلم العراقي كاملاً بدل اللون الأزرق.
    static func flagArrow(_ size: CGFloat = 96) -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { ctx in
            let k = size / 44, c = ctx.cgContext
            let tri = UIBezierPath(); tri.move(to: CGPoint(x: 22 * k, y: 3 * k)); tri.addLine(to: CGPoint(x: 41 * k, y: 42 * k))
            tri.addLine(to: CGPoint(x: 22 * k, y: 34 * k)); tri.addLine(to: CGPoint(x: 3 * k, y: 42 * k)); tri.close()
            c.saveGState(); tri.addClip()
            let h = 39 * k / 3
            for (i, col) in [UIColor(red: 0.81, green: 0.07, blue: 0.15, alpha: 1), .white, .black].enumerated() {
                col.setFill(); c.fill(CGRect(x: 0, y: 3 * k + h * CGFloat(i), width: size, height: h + 1))
            }
            let txt = "الله أكبر" as NSString
            let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 5.5 * k), .foregroundColor: UIColor(red: 0, green: 0.48, blue: 0.24, alpha: 1)]
            let sz = txt.size(withAttributes: attrs); txt.draw(at: CGPoint(x: 22 * k - sz.width / 2, y: 3 * k + h * 1.5 - sz.height / 2 + 2 * k), withAttributes: attrs)
            c.restoreGState()
            UIColor(red: 0.06, green: 0.16, blue: 0.18, alpha: 1).setStroke(); tri.lineWidth = 2.2 * k; tri.lineJoinStyle = .round; tri.stroke()
        }
    }
}
