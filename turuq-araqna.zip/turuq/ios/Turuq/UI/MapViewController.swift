import UIKit
import MapLibre
import Combine

/// يعرض الخريطة ويتابع AppModel. يُستعمل في شاشة الهاتف وفي نافذة CarPlay.
final class MapViewController: UIViewController, MLNMapViewDelegate {
    private let model = AppModel.shared
    private var map: MLNMapView!; private var ctl: MapController!
    private var bag = Set<AnyCancellable>(); private var ready = false

    override func viewDidLoad() {
        super.viewDidLoad()
        map = MLNMapView(frame: view.bounds); map.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        map.delegate = self; map.logoView.isHidden = false; map.setCenter(GeoPoint.baghdad.coord, zoomLevel: 11, animated: false)
        view.addSubview(map); ctl = MapController(map)
        ctl.load(files: model.maps.localFiles(), dark: traitCollection.userInterfaceStyle == .dark) {}
    }
    func mapView(_ m: MLNMapView, didFinishLoading style: MLNStyle) {
        ctl.styleLoaded(style); ready = true
        model.$routes.combineLatest(model.$selected).sink { [weak self] r, s in self?.ctl.showRoutes(r, selected: s) }.store(in: &bag)
        model.$reports.sink { [weak self] in self?.ctl.showReports($0) }.store(in: &bag)
        model.$here.combineLatest(model.$navState).sink { [weak self] loc, st in
            guard let self, let loc else { return }
            let p = st?.position ?? GeoPoint(lat: loc.coordinate.latitude, lon: loc.coordinate.longitude)
            let b = st?.bearing ?? max(0, loc.course)
            self.ctl.setVehicle(p, bearing: b)
            if st != nil { self.ctl.follow(p, bearing: b) }
        }.store(in: &bag)
    }
}
