import Foundation
import CoreLocation
import Combine

/// الحاوية المشتركة بين شاشة الهاتف وشاشة CarPlay (نظير TuruqApp في أندرويد).
@MainActor final class AppModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = AppModel()
    let api = Api(); let nav = NavEngine(); let maps = MapUpdater()
    private let lm = CLLocationManager()

    @Published var here: CLLocation?
    @Published var routes: [Route] = []
    @Published var selected = 0
    @Published var destination: Place?
    @Published var origin: Place?           // nil = موقعي
    @Published var reports: [Report] = []
    @Published var navState: NavState?
    @Published var navigating = false
    @Published var message: String?
    private var poll: Task<Void, Never>?; private var lastReroute = Date.distantPast

    override init() {
        super.init(); lm.delegate = self; lm.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        lm.allowsBackgroundLocationUpdates = true; lm.pausesLocationUpdatesAutomatically = false
    }

    func start() {
        lm.requestWhenInUseAuthorization(); lm.startUpdatingLocation()
        guard poll == nil else { return }
        poll = Task { while !Task.isCancelled {
            if let r = try? await api.reports(near: hereP) { reports = r }
            try? await Task.sleep(nanoseconds: 20_000_000_000) } }
    }
    var hereP: GeoPoint { here.map { GeoPoint(lat: $0.coordinate.latitude, lon: $0.coordinate.longitude) } ?? .baghdad }

    func locationManager(_ m: CLLocationManager, didUpdateLocations l: [CLLocation]) {
        guard let loc = l.last else { return }
        here = loc
        guard navigating else { return }
        nav.update(hereP, speed: max(0, loc.speed)); navState = nav.state
        if nav.state?.offRoute == true, Date().timeIntervalSince(lastReroute) > 15 { lastReroute = Date(); Task { await reroute() } }
        if nav.state?.arrived == true { stopNavigation() }
    }

    func plan(to: Place) async {
        destination = to
        let from = origin.map { GeoPoint(lat: $0.lat, lon: $0.lon) } ?? hereP
        do { routes = try await api.route(from: from, to: GeoPoint(lat: to.lat, lon: to.lon)); selected = 0 }
        catch { message = "تعذّر حساب المسار. تحقق من الاتصال." }
    }
    func setOrigin(_ p: Place?) async { origin = p; if let d = destination { await plan(to: d) } }

    /// المسار من نقطة أخرى للمعاينة فقط؛ عند «ابدأ» يُعاد من موقعك الفعلي.
    func startNavigation() async {
        if origin != nil, let d = destination { origin = nil; await plan(to: d) }
        guard routes.indices.contains(selected) else { return }
        nav.start(routes[selected], from: hereP); navState = nav.state; navigating = true
    }
    func stopNavigation() { nav.stop(); navState = nil; navigating = false }
    func reroute() async {
        guard let d = destination, let r = try? await api.route(from: hereP, to: GeoPoint(lat: d.lat, lon: d.lon)), let f = r.first else { return }
        routes = r; selected = 0; nav.start(f, from: hereP); navState = nav.state
    }
    func report(_ t: ReportType) async {
        do { try await api.report(t, at: hereP); message = "وصل بلاغك للسائقين"; reports = (try? await api.reports(near: hereP)) ?? reports }
        catch { message = "تعذّر إرسال البلاغ" }
    }
}
