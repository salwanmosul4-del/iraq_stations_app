import Foundation

/// عميل الخادم نفسه الذي يستعمله أندرويد؛ لا خادم منفصل لـ iOS.
final class Api {
    static let base = URL(string: "https://api.turuq.example/")!
    private let dec = JSONDecoder()
    let deviceId: String = {
        if let d = UserDefaults.standard.string(forKey: "device") { return d }
        let d = UUID().uuidString; UserDefaults.standard.set(d, forKey: "device"); return d
    }()

    private func get<T: Decodable>(_ path: String, _ q: [String: String]) async throws -> T {
        var c = URLComponents(url: Api.base.appendingPathComponent(path), resolvingAgainstBaseURL: false)!
        c.queryItems = q.map { URLQueryItem(name: $0.key, value: $0.value) }
        let (d, r) = try await URLSession.shared.data(from: c.url!)
        guard (r as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return try dec.decode(T.self, from: d)
    }
    private func post(_ path: String, _ body: [String: Any]) async throws -> Data {
        var r = URLRequest(url: Api.base.appendingPathComponent(path)); r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        r.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (d, resp) = try await URLSession.shared.data(for: r)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return d
    }

    func search(_ q: String, near: GeoPoint?) async throws -> [Place] {
        var p = ["q": q]; if let n = near { p["lat"] = "\(n.lat)"; p["lon"] = "\(n.lon)" }
        return try await (get("v1/search", p) as SearchResponse).places
    }
    func route(from: GeoPoint, to: GeoPoint) async throws -> [Route] {
        let d = try await post("v1/route", ["from_lat": from.lat, "from_lon": from.lon, "to_lat": to.lat, "to_lon": to.lon])
        return try dec.decode(RouteResponse.self, from: d).routes.map { dto in
            let shape = Geo.decodePolyline6(dto.shape)
            var cum = [Double](repeating: 0, count: shape.count)
            for i in 1..<max(1, shape.count) { cum[i] = cum[i - 1] + Geo.distance(shape[i - 1], shape[i]) }
            return Route(dto: dto, shape: shape, cumulative: cum)
        }
    }
    func reports(near c: GeoPoint) async throws -> [Report] {
        try await (get("v1/reports", ["lat": "\(c.lat)", "lon": "\(c.lon)", "radius_km": "25"]) as ReportsResponse).reports
    }
    func report(_ t: ReportType, at p: GeoPoint) async throws { _ = try await post("v1/reports", ["type": t.rawValue, "lat": p.lat, "lon": p.lon, "device": deviceId]) }
    func flag(_ id: String, reason: String) async throws { _ = try await post("v1/reports/\(id)/flag", ["device": deviceId, "reason": reason]) }
}
