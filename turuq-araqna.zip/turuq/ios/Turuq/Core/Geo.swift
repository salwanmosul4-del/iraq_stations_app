import Foundation

enum Geo {
    static func distance(_ a: GeoPoint, _ b: GeoPoint) -> Double {
        let r = 6371000.0, p1 = a.lat * .pi / 180, p2 = b.lat * .pi / 180
        let dp = p2 - p1, dl = (b.lon - a.lon) * .pi / 180
        let h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * r * asin(min(1, sqrt(h)))
    }
    static func bearing(_ a: GeoPoint, _ b: GeoPoint) -> Double {
        let p1 = a.lat * .pi / 180, p2 = b.lat * .pi / 180, dl = (b.lon - a.lon) * .pi / 180
        let y = sin(dl) * cos(p2), x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (atan2(y, x) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
    }
    /// (t, المسافة بالأمتار) إلى أقرب نقطة على القطعة a-b
    static func project(_ p: GeoPoint, _ a: GeoPoint, _ b: GeoPoint) -> (Double, Double) {
        let k = cos(p.lat * .pi / 180)
        let ax = a.lon * k, ay = a.lat, bx = b.lon * k, by = b.lat, px = p.lon * k, py = p.lat
        let dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy
        let t = l == 0 ? 0 : max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / l))
        return (t, hypot(px - (ax + t * dx), py - (ay + t * dy)) * .pi / 180 * 6371000)
    }
    static func decodePolyline6(_ s: String) -> [GeoPoint] {
        let u = Array(s.utf8); var i = 0, lat = 0, lon = 0; var out: [GeoPoint] = []
        while i < u.count {
            for w in 0..<2 {
                var shift = 0, result = 0
                while true { let b = Int(u[i]) - 63; i += 1; result |= (b & 0x1F) << shift; shift += 5; if b < 0x20 { break } }
                let d = (result & 1) != 0 ? ~(result >> 1) : result >> 1
                if w == 0 { lat += d } else { lon += d }
            }
            out.append(GeoPoint(lat: Double(lat) / 1e6, lon: Double(lon) / 1e6))
        }
        return out
    }
}

enum Fmt {
    private static let nf: NumberFormatter = { let f = NumberFormatter(); f.locale = Locale(identifier: "ar-u-nu-arab"); f.maximumFractionDigits = 1; return f }()
    static func num(_ n: Double) -> String { nf.string(from: NSNumber(value: n)) ?? "\(n)" }
    static func dist(_ m: Double) -> String { m < 950 ? num((m / 50).rounded() * 50) + " م" : num((m / 100).rounded() / 10) + " كم" }
    static func minutes(_ s: Double) -> String { let m = max(1, Int((s / 60).rounded())); return m < 60 ? num(Double(m)) + " د" : num(Double(m / 60)) + " س " + num(Double(m % 60)) + " د" }
}
