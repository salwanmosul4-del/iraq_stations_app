import Foundation
import CryptoKit

/// تحديث خرائط المحافظات: manifest → مقارنة الإصدارات → تنزيل → SHA-256 → استبدال ذرّي.
/// ملاحظة iOS: التنزيل الخلفي الحقيقي يحتاج URLSession(background:) و BGAppRefreshTask؛ هنا نسخة أمامية بسيطة.
final class MapUpdater: ObservableObject {
    static let manifestURL = URL(string: "https://maps.turuq.example/manifest.json")!
    private let dir: URL = { let d = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("maps")
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true); return d }()
    private var installedURL: URL { dir.appendingPathComponent("installed.json") }

    func installed() -> [String: Int] { (try? JSONDecoder().decode([String: Int].self, from: Data(contentsOf: installedURL))) ?? [:] }
    private func save(_ m: [String: Int]) { try? JSONEncoder().encode(m).write(to: installedURL, options: .atomic) }
    func localFiles() -> [URL] { installed().keys.map { dir.appendingPathComponent("\($0).mbtiles") }.filter { FileManager.default.fileExists(atPath: $0.path) } }

    func manifest() async throws -> MapManifest { try JSONDecoder().decode(MapManifest.self, from: try await URLSession.shared.data(from: Self.manifestURL).0) }
    func outdated() async throws -> [MapRegion] { let have = installed(); return try await manifest().regions.filter { have[$0.id].map { $0 < $1.version } ?? false } }

    func install(_ r: MapRegion) async throws {
        let (tmp, resp) = try await URLSession.shared.download(from: URL(string: r.url)!)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        var h = SHA256(); let fh = try FileHandle(forReadingFrom: tmp)
        while let chunk = try fh.read(upToCount: 1 << 20), !chunk.isEmpty { h.update(data: chunk) }
        guard h.finalize().map({ String(format: "%02x", $0) }).joined() == r.sha256.lowercased() else { throw URLError(.cannotParseResponse) }
        let target = dir.appendingPathComponent("\(r.id).mbtiles")
        if FileManager.default.fileExists(atPath: target.path) { _ = try FileManager.default.replaceItemAt(target, withItemAt: tmp) }
        else { try FileManager.default.moveItem(at: tmp, to: target) }
        var m = installed(); m[r.id] = r.version; save(m)
    }
}
