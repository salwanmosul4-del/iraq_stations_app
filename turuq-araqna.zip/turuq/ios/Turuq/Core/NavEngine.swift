import Foundation

struct NavState {
    let route: Route; let position: GeoPoint; let bearing: Double; let along: Double; let stepIndex: Int
    let distToManeuver: Double; let remaining: Double; let remainingS: Double
    let nextWarning: RouteWarning?; let warningDist: Double; let offRoute: Bool; let arrived: Bool
    var step: RouteStep { route.steps[stepIndex] }
    var nextStep: RouteStep? { stepIndex + 1 < route.steps.count ? route.steps[stepIndex + 1] : nil }
}

/// نسخة Swift من NavEngine في أندرويد، بالمنطق نفسه: نافذة أمامية، ٣ قراءات خارج ٤٥ م = خارج المسار.
final class NavEngine {
    private(set) var state: NavState?
    private var route: Route?; private var lastIdx = 0; private var offCount = 0

    func start(_ r: Route, from: GeoPoint) { route = r; lastIdx = 0; offCount = 0; update(from, speed: 0) }
    func stop() { route = nil; state = nil }

    func update(_ p: GeoPoint, speed: Double) {
        guard let r = route, r.shape.count >= 2 else { return }
        var bestI = lastIdx, bestD = Double.greatestFiniteMagnitude, bestT = 0.0
        let hi = min(r.shape.count - 2, lastIdx + 60)
        for i in max(0, lastIdx - 2)...hi {
            let (t, d) = Geo.project(p, r.shape[i], r.shape[i + 1]); if d < bestD { bestD = d; bestI = i; bestT = t }
        }
        lastIdx = bestI
        let along = r.cumulative[bestI] + (r.cumulative[bestI + 1] - r.cumulative[bestI]) * bestT
        offCount = bestD > 45 ? offCount + 1 : 0
        let si = max(0, r.steps.lastIndex(where: { $0.beginShapeIndex <= bestI }) ?? 0)
        let stepEnd = r.cumulative[min(max(r.steps[si].endShapeIndex, 0), r.shape.count - 1)]
        let remaining = max(0, r.distanceM - along)
        let avg = r.distanceM / max(1, r.durationS)
        let eff = speed > 3 ? speed * 0.4 + avg * 0.6 : avg
        let warn = r.warnings.filter { $0.distAlongM > along && $0.distAlongM - along < 600 }.min { $0.distAlongM < $1.distAlongM }
        state = NavState(route: r, position: p, bearing: Geo.bearing(r.shape[bestI], r.shape[bestI + 1]), along: along, stepIndex: si,
                         distToManeuver: max(0, stepEnd - along), remaining: remaining, remainingS: remaining / max(0.5, eff),
                         nextWarning: warn, warningDist: warn.map { $0.distAlongM - along } ?? 0, offRoute: offCount >= 3, arrived: remaining < 25)
    }
}
