import Foundation
import CoreLocation

struct GeoPoint: Equatable { var lat: Double; var lon: Double
    var coord: CLLocationCoordinate2D { .init(latitude: lat, longitude: lon) }
    static let baghdad = GeoPoint(lat: 33.3152, lon: 44.3661) }

enum ReportType: String, CaseIterable, Codable {
    case jam, accident, closed, pothole, speedcam, object, flood, works, cam, breakdown
    var label: String { ["jam": "ازدحام", "accident": "حادث", "closed": "طريق مقطوع", "pothole": "حفرة", "speedcam": "كاميرا سرعة",
        "object": "جسم على الطريق", "flood": "مياه وأمطار", "works": "أعمال طرق", "cam": "كاميرا مراقبة", "breakdown": "عطل مركبة"][rawValue]! }
    var onCarGrid: Bool { [.jam, .accident, .closed, .pothole, .speedcam, .object].contains(self) }
    var isCamera: Bool { self == .speedcam || self == .cam }
}

struct Report: Codable, Identifiable { let id: String; let type: String; let lat: Double; let lon: Double
    let createdAt: Int64; var up: Int = 0; var down: Int = 0
    enum CodingKeys: String, CodingKey { case id, type, lat, lon, up, down; case createdAt = "created_at" } }
struct ReportsResponse: Codable { let reports: [Report] }

struct Place: Codable, Identifiable, Equatable { let id: String; let name: String; var area: String = ""; let lat: Double; let lon: Double }
struct SearchResponse: Codable { let places: [Place] }

struct RouteStep: Codable {
    let instruction: String; let type: Int; let lengthM: Double; let timeS: Double
    let beginShapeIndex: Int; let endShapeIndex: Int; let street: String?; let roundaboutExit: Int?
    enum CodingKeys: String, CodingKey { case instruction, type, street
        case lengthM = "length_m", timeS = "time_s", beginShapeIndex = "begin_shape_index", endShapeIndex = "end_shape_index", roundaboutExit = "roundabout_exit" }
}
struct RouteWarning: Codable { let type: String; let distAlongM: Double; let reportId: String
    enum CodingKeys: String, CodingKey { case type; case distAlongM = "dist_along_m"; case reportId = "report_id" } }
struct RouteDto: Codable {
    let id: String; let label: String; let distanceM: Double; let durationS: Double
    let shape: String; let steps: [RouteStep]; var warnings: [RouteWarning] = []
    enum CodingKeys: String, CodingKey { case id, label, shape, steps, warnings
        case distanceM = "distance_m", durationS = "duration_s" } }
struct RouteResponse: Codable { let routes: [RouteDto] }

struct Route { let dto: RouteDto; let shape: [GeoPoint]; let cumulative: [Double]
    var distanceM: Double { dto.distanceM }; var durationS: Double { dto.durationS }
    var steps: [RouteStep] { dto.steps }; var warnings: [RouteWarning] { dto.warnings }; var label: String { dto.label } }

struct MapRegion: Codable, Identifiable { let id: String; let name: String; let version: Int; let url: String; let sha256: String; let bytes: Int64; let bbox: [Double] }
struct MapManifest: Codable { let schema: Int; let generated: String; let regions: [MapRegion] }
