"""
يستخرج المعالم من ملف OSM للعراق إلى places.jsonl (الاسم العربي، الفئة، الإحداثيات، المنطقة).
المتطلبات: pip install osmium
الاستعمال:  python tools/import_osm_places.py iraq-latest.osm.pbf places.jsonl
ثم:         python seed_places.py turuq.db places.jsonl
لم يُختبر على بيانات حقيقية في بيئة الإنشاء (لا وصول للشبكة)؛ جرّبه على محافظة صغيرة أولاً.
"""
import json, sys
import osmium

def cat_of(t):
    a, o, b, p, tour = t.get("amenity"), t.get("office"), t.get("building"), t.get("place"), t.get("tourism")
    if t.get("aeroway") in ("aerodrome", "terminal"): return "airport"
    if o == "government" or a in ("townhall", "courthouse", "police", "public_building", "embassy"): return "government"
    if a in ("hospital", "clinic"): return "hospital"
    if a in ("university", "college"): return "university"
    if a == "school": return "school"
    if a == "place_of_worship" or b in ("mosque", "church"): return "mosque"
    if t.get("shop") == "mall" or b == "retail": return "mall"
    if tour in ("hotel", "attraction", "museum") or t.get("historic"): return "landmark" if tour != "hotel" else "hotel"
    if t.get("railway") == "station" or a == "bus_station": return "station"
    if p in ("suburb", "neighbourhood", "quarter", "village", "town", "city", "locality"): return "area"
    if t.get("man_made") == "bridge" or t.get("bridge") == "yes": return "bridge"
    return None

class H(osmium.SimpleHandler):
    def __init__(self, out):
        super().__init__(); self.out = out; self.n = 0
    def _emit(self, kind, o, lat, lon):
        t = o.tags
        name = t.get("name:ar") or t.get("name")
        if not name: return
        c = cat_of(t)
        if not c: return
        aliases = [v for k, v in ((k, t.get(k)) for k in ("name", "name:en", "alt_name", "short_name", "name:ku")) if v and v != name]
        self.out.write(json.dumps({"id": f"osm-{kind}{o.id}", "name": name, "area": t.get("addr:suburb") or t.get("addr:city") or "",
                                   "cat": c, "lat": round(lat, 6), "lon": round(lon, 6), "aliases": aliases}, ensure_ascii=False) + "\n")
        self.n += 1
    def node(self, n):
        if n.location.valid(): self._emit("n", n, n.location.lat, n.location.lon)
    def area(self, a):
        try:
            # مركز الصندوق المحيط كتقريب كافٍ للمعالم
            bb = [(w.lat, w.lon) for r in a.outer_rings() for w in r]
            if bb: self._emit("a", a, sum(x for x, _ in bb) / len(bb), sum(y for _, y in bb) / len(bb))
        except Exception:
            pass

if __name__ == "__main__":
    with open(sys.argv[2], "w", encoding="utf-8") as out:
        h = H(out); h.apply_file(sys.argv[1], locations=True); print("places:", h.n)
