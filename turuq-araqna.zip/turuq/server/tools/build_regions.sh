#!/usr/bin/env bash
# يبني خرائط المحافظات (MBTiles بمخطط OpenMapTiles) ويكتب manifest.json.
# المتطلبات: java 21+، planetiler.jar، curl، jq، sha256sum. شغّله شهرياً أو عند الحاجة (cron/CI).
# لم يُشغَّل في بيئة الإنشاء (لا وصول للشبكة) — جرّبه على منطقة صغيرة أولاً.
set -euo pipefail
OUT=${OUT:-./out}; BASE_URL=${BASE_URL:-https://maps.turuq.example/regions}
mkdir -p "$OUT"
curl -fL -o "$OUT/iraq.osm.pbf" https://download.geofabrik.de/asia/iraq-latest.osm.pbf
VER=$(date +%Y%m)       # رقم الإصدار: سنة وشهر، يزيد كل بناء
# المحافظات: id|الاسم|min_lon,min_lat,max_lon,max_lat (حدود تقريبية — راجعها)
REGIONS=(
 "baghdad|بغداد|43.95,33.00,44.75,33.70"
 "basra|البصرة|46.90,29.80,48.60,31.20"
 "nineveh|نينوى|41.20,35.40,43.60,36.90"
 "erbil|أربيل|43.50,35.60,45.00,37.10"
 "najaf|النجف|43.20,30.60,45.30,32.50"
 "karbala|كربلاء|43.30,32.20,44.60,33.30"
)
echo '{"schema":1,"generated":"'"$(date -u +%FT%TZ)"'","regions":[]}' > "$OUT/manifest.json"
for R in "${REGIONS[@]}"; do
  IFS='|' read -r ID NAME BB <<<"$R"
  java -Xmx8g -jar planetiler.jar --osm-path="$OUT/iraq.osm.pbf" --output="$OUT/$ID.mbtiles" \
       --bounds="$BB" --maxzoom=14 --download=false --force
  SHA=$(sha256sum "$OUT/$ID.mbtiles" | cut -d' ' -f1); BYTES=$(stat -c%s "$OUT/$ID.mbtiles")
  jq --arg id "$ID" --arg name "$NAME" --argjson v "$VER" --arg url "$BASE_URL/$ID.mbtiles" --arg sha "$SHA" \
     --argjson b "$BYTES" --argjson bb "[${BB}]" \
     '.regions += [{id:$id,name:$name,version:$v,url:$url,sha256:$sha,bytes:$b,bbox:$bb}]' \
     "$OUT/manifest.json" > "$OUT/m.tmp" && mv "$OUT/m.tmp" "$OUT/manifest.json"
done
echo "ارفع $OUT/*.mbtiles ثم manifest.json أخيراً (حتى لا يشير لملف لم يُرفع بعد)."
