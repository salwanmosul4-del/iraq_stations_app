"""يحمّل بذرة المعالم إلى قاعدة البيانات. الاستعمال: python seed_places.py turuq.db data/landmarks_seed.json [places.jsonl ...]"""
import json, sys
import logic as L

def load(db, path):
    n = 0
    with open(path, encoding="utf-8") as f:
        if path.endswith(".jsonl"):
            items = (json.loads(l) for l in f if l.strip())
            verified = 1
        else:
            items = json.load(f)["places"]; verified = 0
        for p in items:
            L.add_place(db, p["id"], p["name"], p.get("area", ""), p.get("cat", "other"), p["lat"], p["lon"],
                        p.get("aliases", []), p.get("verified", verified))
            n += 1
    db.commit()
    return n

if __name__ == "__main__":
    db = L.connect(sys.argv[1])
    for path in sys.argv[2:]:
        print(path, load(db, path))
