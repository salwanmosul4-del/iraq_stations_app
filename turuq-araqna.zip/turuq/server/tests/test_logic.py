import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import logic as L

def enc(pts):
    out, plat, plon = [], 0, 0
    def e(v):
        v = ~(v << 1) if v < 0 else v << 1
        s = ""
        while v >= 0x20:
            s += chr((0x20 | (v & 0x1F)) + 63); v >>= 5
        return s + chr(v + 63)
    for la, lo in pts:
        la, lo = round(la * 1e6), round(lo * 1e6)
        out.append(e(la - plat) + e(lo - plon)); plat, plon = la, lo
    return "".join(out)

class T(unittest.TestCase):
    def test_norm(self):
        self.assertEqual(L.norm("المُستنصريّة"), L.norm("المستنصريه"))
        self.assertEqual(L.norm("إسكان"), L.norm("اسكان"))

    def test_polyline_roundtrip(self):
        pts = [(33.3152, 44.3661), (33.32, 44.37), (33.33, 44.39)]
        got = L.decode_polyline6(enc(pts))
        for a, b in zip(pts, got):
            self.assertAlmostEqual(a[0], b[0], 5); self.assertAlmostEqual(a[1], b[1], 5)

    def test_search_arabic(self):
        db = L.connect()
        L.add_place(db, "1", "الجامعة المستنصرية", "بغداد", "university", 33.347, 44.438, ["Mustansiriyah University", "المستنصريه"])
        L.add_place(db, "2", "وزارة الداخلية", "الكرادة", "government", 33.30, 44.41)
        L.add_place(db, "3", "مطار بغداد الدولي", "بغداد", "airport", 33.262, 44.234, ["مطار بغداد"])
        db.commit()
        self.assertEqual(L.search_places(db, "مستنصريه")[0]["id"], "1")
        self.assertEqual(L.search_places(db, "جامعة المستنصرية")[0]["id"], "1")
        self.assertEqual(L.search_places(db, "داخلية")[0]["id"], "2")
        self.assertEqual(L.search_places(db, "مطار")[0]["id"], "3")
        self.assertEqual(L.search_places(db, "xyz"), [])

    def test_reports_merge_vote_flag_expire(self):
        db = L.connect()
        a, m1 = L.add_report(db, "jam", 33.3, 44.4, "d1", now=1000)
        b, m2 = L.add_report(db, "jam", 33.3002, 44.4001, "d2", now=1010)
        self.assertEqual((a, m1, m2), (b, False, True))
        self.assertEqual(len(L.active_reports(db, 33.3, 44.4, now=1100)), 1)
        self.assertEqual(len(L.active_reports(db, 33.3, 44.4, now=1000 + 10 * 3600)), 0)
        for d in ("x", "y", "z"): L.flag(db, a, d, "كاذب")
        self.assertEqual(len(L.active_reports(db, 33.3, 44.4, now=1100)), 0)
        self.assertFalse(L.flag(db, a, "x", "again"))

    def test_warnings_along_route(self):
        shape = [(33.30, 44.40), (33.31, 44.40), (33.32, 44.40)]
        reps = [{"id": "r1", "type": "speedcam", "lat": 33.315, "lon": 44.4001},
                {"id": "r2", "type": "jam", "lat": 33.315, "lon": 44.42}]
        w = L.warnings_for(shape, reps)
        self.assertEqual([x["report_id"] for x in w], ["r1"])
        self.assertAlmostEqual(w[0]["dist_along_m"], 1670, delta=60)

    def test_rate_limit(self):
        r = L.RateLimiter(2, 60)
        self.assertTrue(r.allow("a", 0)); self.assertTrue(r.allow("a", 1)); self.assertFalse(r.allow("a", 2)); self.assertTrue(r.allow("a", 100))

    def test_arabic_instruction(self):
        self.assertEqual(L.instruction_ar(10, "شارع فلسطين"), "انعطف يميناً إلى شارع فلسطين")
        self.assertIn("الثاني", L.instruction_ar(26, None, 2))

if __name__ == "__main__":
    unittest.main()
