"""خادم «طرق عراقنا»: بلاغات، بحث معالم، توجيه عبر Valhalla. شغّله: uvicorn main:app"""
import os
import time

import httpx
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

import logic as L

DB_PATH = os.environ.get("TURUQ_DB", "turuq.db")
VALHALLA = os.environ.get("VALHALLA_URL", "http://valhalla:8002")
PHOTON = os.environ.get("PHOTON_URL", "")  # اختياري: بحث احتياطي إن قلّت نتائج المعالم

db = L.connect(DB_PATH)
app = FastAPI(title="Turuq Araqna API", version="1.0")
post_limit = L.RateLimiter(12, 3600)      # ١٢ بلاغاً في الساعة لكل جهاز
route_limit = L.RateLimiter(120, 3600)

class NewReport(BaseModel):
    type: str
    lat: float
    lon: float
    device: str

class Vote(BaseModel):
    device: str
    value: int

class Flag(BaseModel):
    device: str
    reason: str = ""

class RouteReq(BaseModel):
    from_lat: float
    from_lon: float
    to_lat: float
    to_lon: float
    avoid_bridges: bool = False

@app.get("/health")
def health():
    return {"ok": True, "time": int(time.time())}

@app.get("/v1/search")
async def search(q: str, lat: float | None = None, lon: float | None = None):
    near = (lat, lon) if lat is not None and lon is not None else None
    places = L.search_places(db, q, near)
    if len(places) < 4 and PHOTON:
        try:
            async with httpx.AsyncClient(timeout=4) as c:
                r = await c.get(PHOTON + "/api", params={"q": q, "limit": 6, "lang": "ar",
                                                          **({"lat": lat, "lon": lon} if near else {})})
            for f in r.json().get("features", []):
                p = f["properties"]; x, y = f["geometry"]["coordinates"]
                places.append({"id": f"photon-{p.get('osm_type','')}{p.get('osm_id','')}", "name": p.get("name") or p.get("street", ""),
                               "area": ", ".join(v for v in (p.get("district"), p.get("city")) if v), "lat": y, "lon": x})
        except Exception:
            pass
    return {"places": places[:8]}

@app.get("/v1/reports")
def reports(lat: float, lon: float, radius_km: float = 25):
    rows = L.active_reports(db, lat, lon, min(radius_km, 60))
    return {"reports": [{"id": r["id"], "type": r["type"], "lat": r["lat"], "lon": r["lon"],
                         "created_at": r["created_at"] * 1000, "up": r["up"], "down": r["down"]} for r in rows]}

@app.post("/v1/reports")
def post_report(body: NewReport, request: Request):
    if not post_limit.allow(body.device):
        raise HTTPException(429, "too many reports")
    if not (28.0 < body.lat < 38.0 and 38.0 < body.lon < 49.0):
        raise HTTPException(400, "outside Iraq")
    try:
        rid, merged = L.add_report(db, body.type, body.lat, body.lon, body.device)
    except ValueError:
        raise HTTPException(400, "unknown type")
    return {"id": rid, "merged": merged}

@app.post("/v1/reports/{rid}/vote")
def vote(rid: str, body: Vote):
    if body.value not in (-1, 1): raise HTTPException(400, "bad value")
    return {"counted": L.vote(db, rid, body.device, body.value)}

@app.post("/v1/reports/{rid}/flag")
def flag(rid: str, body: Flag):
    return {"counted": L.flag(db, rid, body.device, body.reason)}

@app.post("/v1/route")
async def route(req: RouteReq, request: Request):
    ip = request.client.host if request.client else "?"
    if not route_limit.allow(ip):
        raise HTTPException(429, "slow down")
    a, b = (req.from_lat, req.from_lon), (req.to_lat, req.to_lon)
    mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    span_km = L.dist_m(a, b) / 1000
    near = L.active_reports(db, mid[0], mid[1], radius_km=max(10, span_km))
    blocking = [r for r in near if r["type"] in L.BLOCKING]
    payload = {
        "locations": [{"lat": a[0], "lon": a[1]}, {"lat": b[0], "lon": b[1]}],
        "costing": "auto", "directions_options": {"units": "kilometers"},
        "alternates": 2,
        "exclude_polygons": [L.box_polygon(r["lat"], r["lon"]) for r in blocking],
    }
    if req.avoid_bridges:
        payload["costing_options"] = {"auto": {"use_ferry": 0}}
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(VALHALLA + "/route", json=payload)
        data = r.json()
    except Exception:
        raise HTTPException(502, "routing unavailable")
    if "trip" not in data:
        raise HTTPException(404, data.get("error", "no route"))
    trips = [data["trip"]] + [x["trip"] for x in data.get("alternates", [])]
    out = []
    for i, t in enumerate(trips[:3]):
        leg = t["legs"][0]
        shape = L.decode_polyline6(leg["shape"])
        steps = [{
            "instruction": L.instruction_ar(m["type"], (m.get("street_names") or [None])[0], m.get("roundabout_exit_count")),
            "type": m["type"], "length_m": m["length"] * 1000, "time_s": m["time"],
            "begin_shape_index": m["begin_shape_index"], "end_shape_index": m["end_shape_index"],
            "street": (m.get("street_names") or [None])[0], "roundabout_exit": m.get("roundabout_exit_count"),
        } for m in leg["maneuvers"]]
        warns = [w for w in L.warnings_for(shape, near) if True]
        out.append({"id": f"r{i}", "label": "الأسرع" if i == 0 else f"بديل {i}",
                    "distance_m": t["summary"]["length"] * 1000, "duration_s": t["summary"]["time"],
                    "shape": leg["shape"], "steps": steps, "warnings": warns})
    out.sort(key=lambda r: r["duration_s"])
    out[0]["label"] = "الأسرع"
    return {"routes": out}
