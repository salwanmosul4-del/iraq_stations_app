"""منطق الخادم دون اعتماد على FastAPI حتى يمكن اختباره بمكتبة بايثون القياسية فقط."""
import math
import re
import sqlite3
import time
import uuid

# ---------- ثوابت أنواع البلاغات (يجب أن تطابق ReportType في التطبيق) ----------
TTL = {  # ثوانٍ
    "jam": 2 * 3600, "accident": 3 * 3600, "closed": 12 * 3600, "pothole": 14 * 86400,
    "speedcam": 90 * 86400, "object": 3 * 3600, "flood": 6 * 3600, "works": 7 * 86400,
    "cam": 90 * 86400, "breakdown": 2 * 3600,
}
BLOCKING = {"closed", "flood"}           # تُستبعد من التوجيه
WARN_TYPES = set(TTL) - {"works"} | {"works"}
MERGE_RADIUS_M = 100
FLAG_HIDE_AT = 3

# ---------- جغرافيا ----------
R = 6371000.0

def dist_m(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))

def project_m(p, a, b):
    """أقرب نقطة على القطعة a-b للنقطة p. يعيد (t, المسافة بالأمتار) على مستوى محلي."""
    k = math.cos(math.radians(p[0]))
    ax, ay, bx, by, px, py = a[1] * k, a[0], b[1] * k, b[0], p[1] * k, p[0]
    dx, dy = bx - ax, by - ay
    L = dx * dx + dy * dy
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L))
    cx, cy = ax + t * dx, ay + t * dy
    return t, math.hypot(px - cx, py - cy) * math.pi / 180 * R

def decode_polyline6(s):
    pts, i, lat, lon = [], 0, 0, 0
    while i < len(s):
        for which in (0, 1):
            shift = result = 0
            while True:
                b = ord(s[i]) - 63; i += 1
                result |= (b & 0x1F) << shift; shift += 5
                if b < 0x20: break
            d = ~(result >> 1) if result & 1 else result >> 1
            if which == 0: lat += d
            else: lon += d
        pts.append((lat / 1e6, lon / 1e6))
    return pts

def box_polygon(lat, lon, half_m=60):
    dlat = half_m / 111320.0
    dlon = half_m / (111320.0 * math.cos(math.radians(lat)))
    # Valhalla: [lon, lat]
    return [[lon - dlon, lat - dlat], [lon + dlon, lat - dlat], [lon + dlon, lat + dlat], [lon - dlon, lat + dlat]]

def warnings_for(shape, reports, max_off_m=40):
    """يربط كل بلاغ قريب بمسافته على طول المسار. shape = [(lat,lon)]."""
    cum = [0.0]
    for i in range(1, len(shape)):
        cum.append(cum[-1] + dist_m(shape[i - 1], shape[i]))
    out = []
    for r in reports:
        p = (r["lat"], r["lon"])
        best = None
        for i in range(len(shape) - 1):
            t, d = project_m(p, shape[i], shape[i + 1])
            if d <= max_off_m and (best is None or d < best[0]):
                best = (d, cum[i] + (cum[i + 1] - cum[i]) * t)
        if best:
            out.append({"type": r["type"], "dist_along_m": round(best[1], 1), "report_id": r["id"]})
    return sorted(out, key=lambda w: w["dist_along_m"])

# ---------- تعليمات عربية للمناورات (Valhalla لا يوفّر العربية موثوقاً) ----------
_PHRASE = {
    1: "انطلق", 2: "انطلق", 3: "انطلق", 4: "وصلت إلى وجهتك", 5: "وجهتك على يمينك", 6: "وجهتك على يسارك",
    7: "تابع", 8: "تابع بشكل مستقيم", 9: "انحرف قليلاً يميناً", 10: "انعطف يميناً", 11: "انعطف يميناً بحدّة",
    12: "استدر للخلف", 13: "استدر للخلف", 14: "انعطف يساراً بحدّة", 15: "انعطف يساراً", 16: "انحرف قليلاً يساراً",
    17: "تابع على المنحدر", 18: "خذ المنحدر يميناً", 19: "خذ المنحدر يساراً", 20: "اتجه إلى المخرج يميناً",
    21: "اتجه إلى المخرج يساراً", 22: "ابقَ مستقيماً", 23: "ابقَ يميناً", 24: "ابقَ يساراً", 25: "اندمج",
    26: "ادخل الدوّار", 27: "اخرج من الدوّار", 37: "اندمج يميناً", 38: "اندمج يساراً",
}
_ORD = {1: "الأول", 2: "الثاني", 3: "الثالث", 4: "الرابع", 5: "الخامس", 6: "السادس"}

def instruction_ar(mtype, street=None, roundabout_exit=None):
    s = _PHRASE.get(mtype, "تابع")
    if mtype == 26 and roundabout_exit:
        s = f"في الدوّار خذ المخرج {_ORD.get(roundabout_exit, str(roundabout_exit))}"
    if street and mtype not in (4, 5, 6):
        s += f" إلى {street}"
    return s

# ---------- بحث عربي ----------
_TASHKEEL = re.compile("[ً-ٰٟـ]")

def norm(s: str) -> str:
    s = _TASHKEEL.sub("", s or "")
    s = (s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ى", "ي").replace("ة", "ه")
           .replace("ؤ", "و").replace("ئ", "ي"))
    s = re.sub(r"[^\w\s]", " ", s.lower())
    return re.sub(r"\s+", " ", s).strip()

def strip_al(tok: str) -> str:
    return tok[2:] if tok.startswith("ال") and len(tok) > 3 else tok

# أهمية الفئة في الترتيب (الأعلى أولاً)
CAT_WEIGHT = {"airport": 10, "government": 9, "hospital": 9, "university": 9, "landmark": 9, "bridge": 8,
              "mall": 7, "hotel": 6, "mosque": 6, "school": 5, "station": 7, "area": 8, "street": 4, "other": 3}

SCHEMA = """
CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY, type TEXT, lat REAL, lon REAL, created_at INTEGER,
  expires_at INTEGER, up INTEGER DEFAULT 0, down INTEGER DEFAULT 0, flags INTEGER DEFAULT 0, hidden INTEGER DEFAULT 0, device TEXT);
CREATE INDEX IF NOT EXISTS idx_rep_geo ON reports(lat, lon);
CREATE TABLE IF NOT EXISTS votes(report_id TEXT, device TEXT, value INTEGER, PRIMARY KEY(report_id, device));
CREATE TABLE IF NOT EXISTS flag_log(report_id TEXT, device TEXT, reason TEXT, PRIMARY KEY(report_id, device));
CREATE TABLE IF NOT EXISTS places(id TEXT PRIMARY KEY, name TEXT, area TEXT, cat TEXT, lat REAL, lon REAL,
  aliases TEXT DEFAULT '', verified INTEGER DEFAULT 1);
CREATE VIRTUAL TABLE IF NOT EXISTS places_fts USING fts5(norm, content='', tokenize='unicode61');
"""

def connect(path=":memory:"):
    db = sqlite3.connect(path, check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    return db

def add_place(db, pid, name, area, cat, lat, lon, aliases=(), verified=1):
    db.execute("INSERT OR REPLACE INTO places VALUES (?,?,?,?,?,?,?,?)",
               (pid, name, area, cat, lat, lon, "|".join(aliases), verified))
    rowid = db.execute("SELECT rowid FROM places WHERE id=?", (pid,)).fetchone()[0]
    text = " ".join([norm(name)] + [norm(a) for a in aliases] + [norm(area)])
    text += " " + " ".join(strip_al(t) for t in text.split())
    db.execute("INSERT OR REPLACE INTO places_fts(rowid, norm) VALUES (?,?)", (rowid, text))

def search_places(db, q, near=None, limit=8):
    toks = [t for t in norm(q).split() if t]
    if not toks:
        return []
    expr = " AND ".join(f'("{t}"* OR "{strip_al(t)}"*)' for t in toks)
    try:
        rows = db.execute("SELECT p.* FROM places_fts f JOIN places p ON p.rowid=f.rowid WHERE places_fts MATCH ? LIMIT 60", (expr,)).fetchall()
    except sqlite3.OperationalError:
        return []
    qn = norm(q)
    def score(r):
        s = CAT_WEIGHT.get(r["cat"], 3) * 2
        nm = norm(r["name"])
        if nm == qn: s += 30
        elif nm.startswith(qn) or strip_al(nm) .startswith(strip_al(qn)): s += 12
        if near: s -= min(25, dist_m(near, (r["lat"], r["lon"])) / 4000.0)
        return s
    rows = sorted(rows, key=score, reverse=True)[:limit]
    return [{"id": r["id"], "name": r["name"], "area": r["area"], "lat": r["lat"], "lon": r["lon"]} for r in rows]

# ---------- بلاغات ----------
def active_reports(db, lat, lon, radius_km=25, now=None):
    now = now or int(time.time())
    dlat = radius_km / 111.0
    dlon = radius_km / (111.0 * max(0.2, math.cos(math.radians(lat))))
    rows = db.execute("""SELECT * FROM reports WHERE hidden=0 AND expires_at>? AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?""",
                      (now, lat - dlat, lat + dlat, lon - dlon, lon + dlon)).fetchall()
    return [dict(r) for r in rows if dist_m((lat, lon), (r["lat"], r["lon"])) <= radius_km * 1000]

def add_report(db, rtype, lat, lon, device, now=None):
    """يدمج البلاغ مع بلاغ مماثل قريب بدلاً من تكراره. يعيد (id, merged)."""
    if rtype not in TTL:
        raise ValueError("unknown type")
    now = now or int(time.time())
    for r in active_reports(db, lat, lon, radius_km=0.2, now=now):
        if r["type"] == rtype and dist_m((lat, lon), (r["lat"], r["lon"])) <= MERGE_RADIUS_M:
            vote(db, r["id"], device, 1, now)
            return r["id"], True
    rid = uuid.uuid4().hex[:12]
    db.execute("INSERT INTO reports(id,type,lat,lon,created_at,expires_at,device) VALUES (?,?,?,?,?,?,?)",
               (rid, rtype, lat, lon, now, now + TTL[rtype], device))
    db.commit()
    return rid, False

def vote(db, rid, device, value, now=None):
    now = now or int(time.time())
    row = db.execute("SELECT type FROM reports WHERE id=?", (rid,)).fetchone()
    if not row: return False
    old = db.execute("SELECT value FROM votes WHERE report_id=? AND device=?", (rid, device)).fetchone()
    if old: return False
    db.execute("INSERT INTO votes VALUES (?,?,?)", (rid, device, value))
    if value > 0:
        db.execute("UPDATE reports SET up=up+1, expires_at=MAX(expires_at, ?) WHERE id=?", (now + TTL[row["type"]] // 2, rid))
    else:
        db.execute("UPDATE reports SET down=down+1, expires_at=expires_at-? WHERE id=?", (TTL[row["type"]] // 4, rid))
        db.execute("UPDATE reports SET hidden=1 WHERE id=? AND down>=3 AND down>up*2", (rid,))
    db.commit()
    return True

def flag(db, rid, device, reason):
    if not db.execute("SELECT 1 FROM reports WHERE id=?", (rid,)).fetchone(): return False
    try:
        db.execute("INSERT INTO flag_log VALUES (?,?,?)", (rid, device, reason[:200]))
    except sqlite3.IntegrityError:
        return False
    db.execute("UPDATE reports SET flags=flags+1 WHERE id=?", (rid,))
    db.execute("UPDATE reports SET hidden=1 WHERE id=? AND flags>=?", (rid, FLAG_HIDE_AT))
    db.commit()
    return True

class RateLimiter:
    def __init__(self, limit, window_s):
        self.limit, self.window, self.hits = limit, window_s, {}
    def allow(self, key, now=None):
        now = now or time.time()
        h = [t for t in self.hits.get(key, []) if now - t < self.window]
        if len(h) >= self.limit:
            self.hits[key] = h
            return False
        h.append(now); self.hits[key] = h
        return True
