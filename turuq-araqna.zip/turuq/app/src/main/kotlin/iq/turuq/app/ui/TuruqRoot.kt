package iq.turuq.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import iq.turuq.core.TuruqApp
import iq.turuq.core.maps.MapController
import iq.turuq.core.model.GeoPoint
import iq.turuq.core.model.MapRegion
import iq.turuq.core.model.Place
import iq.turuq.core.model.ReportType
import iq.turuq.core.util.Fmt
import kotlinx.coroutines.launch
import org.maplibre.android.maps.MapView

private val Teal = Color(0xFF0E7C86)
private val Ink = Color(0xFF0F2A2E)
private val Red = Color(0xFFCE1126)

private enum class Panel { None, Report, Maps }

@Composable
fun TuruqRoot(app: TuruqApp, onNavStateChanged: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var welcome by remember { mutableStateOf(!ctx.getSharedPreferences("turuq", 0).getBoolean("welcomed", false)) }
    var panel by remember { mutableStateOf(Panel.None) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var fromQuery by remember { mutableStateOf("") }
    var fromResults by remember { mutableStateOf<List<Place>>(emptyList()) }
    var showFrom by remember { mutableStateOf(false) }
    val origin by app.origin.collectAsState()

    val routes by app.routes.collectAsState()
    val selected by app.selected.collectAsState()
    val reports by app.reports.collectAsState()
    val navigating by app.navigating.collectAsState()
    val nav by app.nav.state.collectAsState()
    val loc by app.location.last.collectAsState()
    val dest by app.destination.collectAsState()
    val message by app.message.collectAsState()

    var controller by remember { mutableStateOf<MapController?>(null) }
    val dark = androidx.compose.foundation.isSystemInDarkTheme()

    LaunchedEffect(navigating) { onNavStateChanged(navigating) }
    LaunchedEffect(controller, routes, selected) { controller?.showRoutes(routes, selected); routes.getOrNull(selected)?.let { if (!navigating) controller?.fit(it) } }
    LaunchedEffect(controller, reports) { controller?.showReports(reports) }
    LaunchedEffect(controller, dest) { controller?.showDestination(dest?.let { GeoPoint(it.lat, it.lon) }) }
    LaunchedEffect(controller, loc, nav) {
        val c = controller ?: return@LaunchedEffect
        val l = loc ?: return@LaunchedEffect
        val p = nav?.position ?: GeoPoint(l.latitude, l.longitude)
        val b = nav?.bearing ?: l.bearing.toDouble()
        c.setVehicle(p, b)
        if (nav != null) c.follow(p, b) else if (routes.isEmpty()) c.overview(p, 13.0)
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            MapView(c).also { mv ->
                mv.onCreate(null); mv.onStart(); mv.onResume()
                mv.getMapAsync { m ->
                    val ctl = MapController(c, m)
                    ctl.load(app.maps.localFiles(), dark) { controller = ctl }
                    ctl.overview(app.here(), 12.0)
                }
            }
        })

        if (!navigating) {
            Column(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp)) {
                Surface(shape = RoundedCornerShape(18.dp), shadowElevation = 6.dp, color = Color.White) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("إلى أين تريد الذهاب؟") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = {
                            scope.launch { results = runCatching { app.api.search(query, app.here()) }.getOrDefault(emptyList()) }
                        }),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                    )
                }
                // «من»: افتراضياً موقعي، ويمكن اختيار منطقة أو مبنى أو دائرة حكومية
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(onClick = { showFrom = !showFrom },
                        label = { Text("من: " + (origin?.name ?: "موقعي")) })
                    if (origin != null) TextButton(onClick = { app.setOrigin(null); fromQuery = "" }) { Text("موقعي") }
                }
                if (showFrom) {
                    Surface(shape = RoundedCornerShape(18.dp), shadowElevation = 6.dp, color = Color.White) {
                        OutlinedTextField(
                            value = fromQuery, onValueChange = { fromQuery = it },
                            placeholder = { Text("ابدأ من: منطقة، مبنى، دائرة…") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = {
                                scope.launch { fromResults = runCatching { app.api.search(fromQuery, app.here()) }.getOrDefault(emptyList()) }
                            }),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                        )
                    }
                    fromResults.take(5).forEach { p ->
                        Surface(Modifier.fillMaxWidth().padding(top = 4.dp).clickable { app.setOrigin(p); fromResults = emptyList(); showFrom = false; fromQuery = p.name },
                            shape = RoundedCornerShape(12.dp), color = Color.White) {
                            Text(p.name + if (p.area.isNotBlank()) " · " + p.area else "", Modifier.padding(12.dp), color = Ink)
                        }
                    }
                }
                if (results.isNotEmpty()) {
                    Surface(Modifier.padding(top = 8.dp), shape = RoundedCornerShape(16.dp), shadowElevation = 6.dp, color = Color.White) {
                        LazyColumn(Modifier.heightIn(max = 280.dp)) {
                            items(results) { p ->
                                Column(Modifier.fillMaxWidth().clickable { app.plan(p); results = emptyList(); query = p.name }.padding(14.dp)) {
                                    Text(p.name, fontWeight = FontWeight.Bold, color = Ink)
                                    if (p.area.isNotBlank()) Text(p.area, fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }

        // شريط الملاحة العلوي
        AnimatedVisibility(navigating && nav != null, Modifier.align(Alignment.TopCenter)) {
            nav?.let { st ->
                Surface(Modifier.statusBarsPadding().padding(12.dp), shape = RoundedCornerShape(20.dp), color = Ink, shadowElevation = 8.dp) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text(Fmt.dist(st.distToManeuverM), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text(st.step.instruction, color = Color.White, fontSize = 16.sp)
                        st.nextWarning?.let { w ->
                            val t = ReportType.fromKey(w.type)
                            Text("⚠ " + (t?.labelAr ?: w.type) + " بعد " + Fmt.dist(st.warningDistM),
                                color = Color(0xFFFFC857), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }

        // الأسفل: بطاقات المسارات أو ملخص الرحلة
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(12.dp)) {
            message?.let { m ->
                Surface(shape = RoundedCornerShape(14.dp), color = Ink, modifier = Modifier.padding(bottom = 8.dp).clickable { app.message.value = null }) {
                    Text(m, color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                }
            }
            if (navigating && nav != null) {
                Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 8.dp) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(Fmt.minutes(nav!!.remainingS), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = Teal)
                            Text(Fmt.dist(nav!!.remainingM), color = Color.Gray)
                        }
                        Button(onClick = { panel = Panel.Report }, colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("أبلغ") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { app.stopNavigation() }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("إنهاء") }
                    }
                }
            } else if (routes.isNotEmpty()) {
                Surface(shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 8.dp) {
                    Column(Modifier.padding(14.dp)) {
                        routes.take(3).forEachIndexed { i, r ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(if (i == selected) Color(0xFFE3F3F2) else Color.Transparent)
                                    .clickable { app.selected.value = i }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(Fmt.minutes(r.durationS) + " · " + Fmt.dist(r.distanceM), fontWeight = FontWeight.Bold, color = Ink)
                                    Text(r.label + if (r.warnings.isNotEmpty()) " · " + Fmt.num(r.warnings.size) + " تنبيه على الطريق" else "", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                        Button(onClick = { app.startNavigation() }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("ابدأ", fontSize = 18.sp) }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    FloatingActionButton(onClick = { panel = Panel.Maps }, containerColor = Color.White) { Text("🗺") }
                    FloatingActionButton(onClick = { panel = Panel.Report }, containerColor = Teal, contentColor = Color.White) { Text("⚠", fontSize = 22.sp) }
                }
            }
        }

        if (panel == Panel.Report) ReportSheet(onPick = { app.report(it); panel = Panel.None }, onClose = { panel = Panel.None })
        if (panel == Panel.Maps) MapsSheet(app, onClose = { panel = Panel.None })
        if (welcome) WelcomeRobot(onDone = { ctx.getSharedPreferences("turuq", 0).edit().putBoolean("welcomed", true).apply(); welcome = false })
    }
}

@Composable
private fun ReportSheet(onPick: (ReportType) -> Unit, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onClose)) {
        Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), color = Color.White) {
            Column(Modifier.navigationBarsPadding().padding(18.dp)) {
                Text("ماذا ترى على الطريق؟", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.height(12.dp))
                ReportType.entries.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { t ->
                            Box(
                                Modifier.weight(1f).height(72.dp).clip(RoundedCornerShape(14.dp))
                                    .background(if (t.isCamera) Color(0xFFEDE7FB) else Color(0xFFF1F5F5)).clickable { onPick(t) },
                                contentAlignment = Alignment.Center,
                            ) { Text(t.labelAr, fontWeight = FontWeight.Bold, color = Ink, fontSize = 13.sp) }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MapsSheet(app: TuruqApp, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var regions by remember { mutableStateOf<List<MapRegion>>(emptyList()) }
    var installed by remember { mutableStateOf(app.maps.installed()) }
    var progress by remember { mutableStateOf<Map<String, Float>>(emptyMap()) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { runCatching { app.maps.manifest().regions }.onSuccess { regions = it }.onFailure { error = "تعذّر جلب قائمة الخرائط" } }

    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onClose)) {
        Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = 520.dp), shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), color = Color.White) {
            Column(Modifier.navigationBarsPadding().padding(18.dp)) {
                Text("خرائط بلا إنترنت", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Ink)
                Text("تُحدَّث تلقائياً على الواي فاي حين يصدر إصدار أحدث.", fontSize = 12.sp, color = Color.Gray)
                error?.let { Text(it, color = Red) }
                LazyColumn {
                    items(regions) { r ->
                        val have = installed[r.id]
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name, fontWeight = FontWeight.Bold, color = Ink)
                                Text(Fmt.num(r.bytes / 1_000_000) + " ميغابايت" + if (have != null && have < r.version) " · يوجد تحديث" else "", fontSize = 12.sp, color = Color.Gray)
                            }
                            val p = progress[r.id]
                            when {
                                p != null -> CircularProgressIndicator(progress = { p }, modifier = Modifier.size(28.dp), color = Teal)
                                have == null || have < r.version -> Button(onClick = {
                                    progress = progress + (r.id to 0f)
                                    scope.launch {
                                        runCatching { app.maps.install(r) { f -> progress = progress + (r.id to f) } }
                                            .onFailure { error = "فشل التنزيل، سيُستأنف لاحقاً" }
                                        progress = progress - r.id; installed = app.maps.installed()
                                    }
                                }, colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text(if (have == null) "تنزيل" else "تحديث") }
                                else -> Text("✓ محدّثة", color = Teal, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** روبوت ترحيب: يشير بيده إلى الرسالة. رسم برمجي بسيط يكفي للإصدار الأول. */
@Composable
private fun WelcomeRobot(onDone: () -> Unit) {
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "wave")
    val angle by t.animateFloat(-18f, 18f, androidx.compose.animation.core.infiniteRepeatable(
        androidx.compose.animation.core.tween(700), androidx.compose.animation.core.RepeatMode.Reverse), label = "a")
    Box(Modifier.fillMaxSize().background(Color(0xE60F2A2E)).clickable(onClick = onDone), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Box(Modifier.size(150.dp)) {
                Box(Modifier.align(Alignment.Center).size(120.dp).clip(RoundedCornerShape(36.dp)).background(Color.White)) {
                    Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                        Box(Modifier.size(18.dp).clip(CircleShape).background(Teal))
                        Box(Modifier.size(18.dp).clip(CircleShape).background(Teal))
                    }
                }
                Box(Modifier.align(Alignment.CenterEnd).size(34.dp).graphicsLayerRotate(angle).clip(CircleShape).background(Red))
            }
            Spacer(Modifier.height(20.dp))
            Text("أهلاً بك في أفضل تطبيق عراقي للطرق", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text("اضغط للمتابعة", color = Color(0xFFB9D5DC))
        }
    }
}

private fun Modifier.graphicsLayerRotate(deg: Float) = this.then(Modifier.graphicsLayer { rotationZ = deg })
